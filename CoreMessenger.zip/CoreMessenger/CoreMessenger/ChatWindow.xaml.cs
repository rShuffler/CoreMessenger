﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MessengerApp
{
    public partial class ChatWindow : Window
    {
        private List<Message> messages;
        private string currentUser = "You";  // Пример имени, можно заменить на реальное имя пользователя
        private string currentChat = "CoreMessenger";  // Изначально выбран чат с официальным мессенджером

        public ChatWindow()
        {
            InitializeComponent();
            messages = new List<Message>();

            // Приветственное сообщение от CoreMessenger
            AddSystemMessage("Welcome to CoreMessenger! This is the official chat. Enjoy your stay!");

            // Приветственное сообщение от бота
            AddBotMessage("Hello! I'm CoreBot. How can I assist you today?");
        }

        // Обработчик события для кнопки "Profile"
        private void ProfileButton_Click(object sender, RoutedEventArgs e)
        {
            ProfileWindow profileWindow = new ProfileWindow();  // Здесь ProfileWindow - это окно с профилем
            profileWindow.Show();  // Открываем окно профиля
        }

        // Обработчик события для кнопки "Stickers"
        private void StickersButton_Click(object sender, RoutedEventArgs e)
        {
            StickersWindow stickersWindow = new StickersWindow();  // Создаём окно с стикерами
            stickersWindow.Show();  // Открываем окно с стикерами
        }

        // Метод для отправки сообщения
        private void SendMessage(object sender, RoutedEventArgs e)
        {
            string messageText = MessageInput.Text;
            if (!string.IsNullOrEmpty(messageText))
            {
                Message newMessage = new Message
                {
                    Username = currentUser,
                    MessageText = AddEmojis(messageText)  // Преобразуем текст с смайликами
                };
                messages.Add(newMessage);
                DisplayMessage(newMessage);  // Отображаем сообщение
                MessageInput.Clear(); // Очищаем поле ввода

                // Бот отвечает только в выбранном чате
                if (currentChat == "CoreBot")
                {
                    BotReply(messageText);
                }
            }
            else
            {
                MessageBox.Show("Please enter a message.");
            }
        }

        // Метод для отправки сообщения от бота
        private async void BotReply(string userMessage)
        {
            // Имитация задержки для ответа бота
            await Task.Delay(1000);  // Задержка 1 секунда (можно увеличить)

            string botResponse = "I'm not sure how to respond to that, but I’m here to help!";

            // Простой ответ бота
            if (userMessage.ToLower().Contains("hello"))
            {
                botResponse = "Hi there! How can I help you today?";
            }
            else if (userMessage.ToLower().Contains("how are you"))
            {
                botResponse = "I'm just a bot, but I'm doing great! Thank you for asking.";
            }

            // Создаём сообщение от бота
            Message botMessage = new Message
            {
                Username = "CoreBot",
                MessageText = AddEmojis(botResponse)  // Преобразуем текст с смайликами
            };

            // Отображаем сообщение от бота в чате с ботом
            DisplayMessage(botMessage);
        }

        // Метод для отображения сообщений
        private void DisplayMessage(Message message)
        {
            StackPanel messagePanel = new StackPanel { Orientation = Orientation.Horizontal };

            if (message.Username == currentUser)
            {
                // Сообщение от текущего пользователя (справа)
                messagePanel.HorizontalAlignment = HorizontalAlignment.Right;
                var messageTextBlock = new TextBlock
                {
                    Text = message.MessageText,
                    Background = new SolidColorBrush(Color.FromArgb(255, 0, 128, 255)),  // Голубой цвет для сообщений пользователя
                    Foreground = Brushes.White,
                    Padding = new Thickness(10),
                    Margin = new Thickness(5),
                    MaxWidth = 400,
                    TextWrapping = TextWrapping.Wrap
                };

                // Оборачиваем в Border для округления углов
                var border = new Border
                {
                    Child = messageTextBlock,
                    CornerRadius = new CornerRadius(10),
                    Background = new SolidColorBrush(Color.FromArgb(255, 0, 128, 255)),
                };

                messagePanel.Children.Add(border);
            }
            else
            {
                // Сообщение от собеседника (слева)
                messagePanel.HorizontalAlignment = HorizontalAlignment.Left;
                var messageTextBlock = new TextBlock
                {
                    Text = message.MessageText,
                    Background = new SolidColorBrush(Color.FromArgb(255, 220, 220, 220)),  // Светло-серый цвет для сообщений собеседника
                    Foreground = Brushes.Black,
                    Padding = new Thickness(10),
                    Margin = new Thickness(5),
                    MaxWidth = 400,
                    TextWrapping = TextWrapping.Wrap
                };

                // Оборачиваем в Border для округления углов
                var border = new Border
                {
                    Child = messageTextBlock,
                    CornerRadius = new CornerRadius(10),
                    Background = new SolidColorBrush(Color.FromArgb(255, 220, 220, 220)),
                };

                messagePanel.Children.Add(border);
            }

            MessagesStack.Children.Add(messagePanel);
            MessagesScrollViewer.ScrollToEnd();  // Прокручиваем до последнего сообщения
        }

        // Метод для добавления системного сообщения (например, приветственного)
        private void AddSystemMessage(string messageText)
        {
            var systemMessage = new Message
            {
                Username = "System",
                MessageText = messageText
            };

            // Отображаем системное сообщение
            DisplayMessage(systemMessage);
        }

        // Метод для добавления сообщения от бота
        private void AddBotMessage(string messageText)
        {
            var botMessage = new Message
            {
                Username = "CoreBot",
                MessageText = messageText
            };

            // Отображаем сообщение от бота
            DisplayMessage(botMessage);
        }

        // Метод для добавления смайликов
        private string AddEmojis(string message)
        {
            message = message.Replace(":)", "😊");
            message = message.Replace(":(", "😞");
            message = message.Replace(":D", "😄");
            message = message.Replace(";)", "😉");

            return message;
        }

        // Обработчик события для выбора чата
        private void ChatsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ChatsList.SelectedItem != null)
            {
                currentChat = ((ListBoxItem)ChatsList.SelectedItem).Content.ToString();
                MessagesStack.Children.Clear();  // Очищаем предыдущие сообщения

                // Приветственное сообщение от CoreMessenger для чата с мессенджером
                if (currentChat == "CoreMessenger ✔")
                {
                    AddSystemMessage("Welcome to the official CoreMessenger chat.");
                }
                // Приветственное сообщение от бота для чата с ботом
                else if (currentChat == "CoreBot")
                {
                    AddBotMessage("Hello! I'm CoreBot. How can I assist you today?");
                }
            }
        }

        // Обработчик события для перетаскивания файлов
        private void MessagesStack_PreviewDragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))  // Проверяем, что перетаскивают файл
            {
                e.Effects = DragDropEffects.Copy;  // Разрешаем копирование
            }
            else
            {
                e.Effects = DragDropEffects.None;  // Запрещаем любые другие операции
            }
        }

        // Обработчик события для обработки сброшенных файлов
        private void MessagesStack_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);

                // Вставляем изображение
                foreach (var file in files)
                {
                    if (IsImage(file))
                    {
                        DisplayImageMessage(file);  // Добавляем изображение в чат
                    }
                }
            }
        }

        // Проверка, является ли файл изображением
        private bool IsImage(string filePath)
        {
            string[] imageExtensions = { ".jpg", ".jpeg", ".png", ".gif", ".bmp" };
            string fileExtension = Path.GetExtension(filePath).ToLower();
            return imageExtensions.Contains(fileExtension);
        }

        // Метод для отображения изображения в сообщении
        private void DisplayImageMessage(string filePath)
        {
            StackPanel messagePanel = new StackPanel { Orientation = Orientation.Horizontal };

            // Сообщение с изображением
            var image = new System.Windows.Controls.Image
            {
                Source = new System.Windows.Media.Imaging.BitmapImage(new Uri(filePath)),
                Width = 200,
                Height = 200,
                Margin = new Thickness(5)
            };

            var border = new Border
            {
                Child = image,
                CornerRadius = new CornerRadius(10),
                Background = new SolidColorBrush(Color.FromArgb(255, 220, 220, 220))
            };

            messagePanel.Children.Add(border);
            MessagesStack.Children.Add(messagePanel);
            MessagesScrollViewer.ScrollToEnd();  // Прокручиваем до последнего сообщения
        }

        // Метод для добавления стикера в сообщение
        public void AddStickerToMessage(string sticker)
        {
            string messageText = MessageInput.Text;
            MessageInput.Text = messageText + " " + sticker;  // Добавляем стикер в текст сообщения
        }

        // Обработчик выбора стикера
        private void OnStickerSelected(string stickerPath)
        {
            AddStickerToMessage(stickerPath);  // Добавляем выбранный стикер в сообщение
        }
    }

    // Класс сообщения
    public class Message
    {
        public string Username { get; set; }
        public string MessageText { get; set; }
    }
}
