﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace MessengerApp
{
    public partial class StickersWindow : Window
    {
        // Событие для передачи выбранного стикера в главное окно
        public event Action<string> StickerSelected;

        public StickersWindow()
        {
            InitializeComponent();
        }

        // Обработчик клика по стикеру
        private void Sticker_Click(object sender, RoutedEventArgs e)
        {
            // Получаем путь к стикеру из источника изображения
            Button button = sender as Button;
            if (button != null)
            {
                Image image = button.Content as Image;
                if (image != null)
                {
                    string stickerPath = image.Source.ToString();
                    // Вызываем событие, передавая путь стикера
                    StickerSelected?.Invoke(stickerPath);
                    this.Close();  // Закрываем окно с стикерами после выбора
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
