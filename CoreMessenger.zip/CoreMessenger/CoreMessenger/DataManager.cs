﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace MessengerApp
{
    public static class DataManager
    {
        // Путь к файлу, где будут сохраняться чаты
        private static string filePath = "chats.dat";

        // Метод для загрузки чатов из файла
        public static List<Chat> LoadChats()
        {
            if (File.Exists(filePath)) // Проверяем, существует ли файл
            {
                try
                {
                    using (FileStream fs = new FileStream(filePath, FileMode.Open))
                    {
                        var formatter = new BinaryFormatter();
                        return (List<Chat>)formatter.Deserialize(fs); // Десериализация чатов из файла
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка при загрузке чатов: {ex.Message}");
                    return new List<Chat>(); // Если ошибка — возвращаем пустой список
                }
            }
            return new List<Chat>(); // Если файл не найден — возвращаем пустой список
        }

        // Метод для сохранения чатов в файл
        public static void SaveChats(List<Chat> chats)
        {
            try
            {
                using (FileStream fs = new FileStream(filePath, FileMode.Create))
                {
                    var formatter = new BinaryFormatter();
                    formatter.Serialize(fs, chats); // Сериализация чатов в файл
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при сохранении чатов: {ex.Message}");
            }
        }
    }
}
