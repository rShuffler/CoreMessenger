﻿using System;
using System.Text.RegularExpressions;

namespace MessengerApp
{
    public static class EmojiHelper
    {
        // Метод для замены текстовых смайликов на эмодзи
        public static string AddEmojis(string message)
        {
            // Пример замен: :) на 😊, :( на 😞
            message = Regex.Replace(message, @":\)", "😊"); // Заменяем :) на 😊
            message = Regex.Replace(message, @":\(", "😞"); // Заменяем :( на 😞

            // Можно добавить больше замен для других смайликов, например:
            message = Regex.Replace(message, @":D", "😄"); // Заменяем :D на 😄
            message = Regex.Replace(message, @";\)", "😉"); // Заменяем ;) на 😉

            return message;
        }
    }
}
