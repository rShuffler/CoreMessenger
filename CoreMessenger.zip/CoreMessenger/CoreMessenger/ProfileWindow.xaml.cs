﻿using CoreMessenger;
using System;
using System.Windows;

namespace MessengerApp
{
    public partial class ProfileWindow : Window
    {
        public string UserNickname { get; set; }

        public ProfileWindow()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(NicknameTextBox.Text))
            {
                UserNickname = NicknameTextBox.Text; // Сохраняем введённый ник

                // Проверяем, открыто ли окно как диалоговое
                if (this.Owner != null)
                {
                    this.DialogResult = true; // Закрываем окно, если оно диалоговое
                }
                else
                {
                    this.Close(); // Просто закрываем, если окно открыто через Show()
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid nickname.");
            }
        }

        private void BuyCoreButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Создаем экземпляр окна BuyCore+
                Buy_Core_ buyCoreWindow = new Buy_Core_();

                // Открываем окно
                buyCoreWindow.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}"); // Сообщение об ошибке
            }
        }

    }
}
