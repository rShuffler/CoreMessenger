﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace MessengerApp
{
    public partial class MainWindow : Window
    {
        private TcpClient client;
        private NetworkStream stream;

        public MainWindow()
        {
            InitializeComponent();
            try
            {
                // Подключаемся к серверу
                client = new TcpClient("127.0.0.1", 8888); // Убедитесь, что сервер работает по этому адресу и порту
                stream = client.GetStream();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error connecting to server: " + ex.Message);
            }
        }

        // Асинхронный метод для регистрации пользователя
        private async void RegisterUser(object sender, RoutedEventArgs e)
        {
            string username = UsernameInput.Text;
            string password = PasswordInput.Password;

            if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password))
            {
                string registrationData = $"REGISTER:{username}:{password}";
                byte[] data = Encoding.UTF8.GetBytes(registrationData);

                try
                {
                    // Отправка данных на сервер
                    await stream.WriteAsync(data, 0, data.Length);
                    MessageBox.Show("Registration request sent to server.");

                    // Получение ответа от сервера (ожидаем подтверждение)
                    byte[] responseBuffer = new byte[1024];
                    int bytesRead = await stream.ReadAsync(responseBuffer, 0, responseBuffer.Length);
                    string response = Encoding.UTF8.GetString(responseBuffer, 0, bytesRead);

                    // Если сервер отправил успешный ответ, показываем окно чатов
                    if (response.Contains("Registration Successful"))
                    {
                        MessageBox.Show("Registration successful!");

                        // Переводим на экран чатов после регистрации
                        ChatWindow chatWindow = new ChatWindow();
                        chatWindow.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Registration failed: " + response);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while sending registration: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please fill in both fields.");
            }
        }

        // Закрытие соединения при закрытии окна
        protected override void OnClosed(EventArgs e)
        {
            stream?.Close();
            client?.Close();
            base.OnClosed(e);
        }
    }
}
