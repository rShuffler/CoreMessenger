﻿using System;
using System.Collections.Generic;

namespace MessengerApp
{
    public class ChatMessage
    {
        public string Username { get; set; }
        public string MessageText { get; set; }
        public DateTime Timestamp { get; set; } // Для хранения времени отправки сообщения
    }

    public class Chat
    {
        public string ChatName { get; set; } // Имя чата (например, CoreMessenger)
        public List<ChatMessage> Messages { get; set; } // Сообщения в чате

        public Chat()
        {
            Messages = new List<ChatMessage>();
        }
    }
}
